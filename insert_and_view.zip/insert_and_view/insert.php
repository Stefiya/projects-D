<?php
$link=mysqli_connect("localhost","root","","insert_view");

if($link===false)
{
die("error:could not connect".mysqli_connect_error());
}
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
if(!empty($fname)&&!empty($lname)&&!empty($email))
{
$sql="INSERT INTO view(fname,lname,email)
		VALUES ('$fname','$lname','$email')";
	if(mysqli_query($link,$sql))
	{
		header("location:view.php");
	}
	else
	{
		echo "error$sql".mysqli_error($link);
	}
}
else
{
	header('location:view.php');
}
mysqli_close($link);
?>