<html>
<head>
<title> </title>
</head>
<body>
<h2>php</h2>
<form action="<?php echo base_url()?>Main/insrtFruit" method="post">
<input type="text" name="fruit">
<input type="submit" name="ok">
</form>
</body>
</html>
