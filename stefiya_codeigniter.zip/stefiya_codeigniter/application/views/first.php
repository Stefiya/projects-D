<html>
<head>
<title> </title>
</head>
<body>
<h2>php</h2>
<p>PHP is a general-purpose scripting language especially suited to web development.
 It was originally created by Danish-Canadian programmer Rasmus Lerdorf in 1994. 
 The PHP reference implementation is now produced by The PHP Group.</p>
</body>
</html>
