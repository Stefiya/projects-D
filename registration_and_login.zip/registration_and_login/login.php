
<!DOCTYPE html>
<html>
<head>
<title>login and register</title>
<style>
body,input{
border:2px solid;
padding:10px;
margin:10px;
}
</style>
</head>
<body>
<form action="logincheck.php" method="POST">
<h1>LOGIN</h1>
 email:<input type="email" name="email"></br>
 password:<input type="password" name="password"></br>

 <input type="submit" value="login">
 </form>
</body>
</html>
