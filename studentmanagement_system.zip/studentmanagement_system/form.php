<!DOCTYPE html>
<html>
<head>
<title>student management system</title>
<style>
body{
border:2px solid;
padding:30px;
}
</style>
</head>
<body>
<form action="insertion.php" method="POST">
<h1>Student detail form</h1>
student name:<input type="text" name="student_name" ></br></br>
student roll number:<input type="text" name="student_rolno"></br></br>
student address:<input type="text" name="student_address"></br></br>
student email:<input type="email" name="student_email"></br>
<input type="submit" value="login">
</form>
</body>
</html>