<html>
<head>
<title></title>
<style>
body,input{
border:2px solid;
padding:10px;
margin:10px;
}
table,th,td{
border:1px solid;
border-collapse:collapse;
}
</style>
<body>
<form action="insert.php" method="POST">

<h1>Insert and View</h1>
 first name:<input type="text" name="fname" ></br></br>
 last name:<input type="text" name="lname" ></br></br>
 email:<input type="email" name="email"></br>
 <input type="submit" value="submit">

<?php
$link=mysqli_connect("localhost","root","","insert_view");
if($link===false)
{
die("error:could not connect".mysqli_connect_error());

}
$sql = "SELECT * FROM view";
if($result=mysqli_query($link, $sql))
{
if(mysqli_num_rows($result)>0)
{


echo "<table>";
echo "<tr>";
echo "<th> id</th>";
echo "<th> fname </th>";
echo "<th> lname </th>";
echo "<th>email</th>";
echo "<th>view</th>";
echo "<th>update</th>";
echo "<th>delete</th>";
            echo "</tr>";
while($row=mysqli_fetch_array($result))
{


echo "<tr>";
echo "<td>".$row['id']."</td>";
echo "<td>".$row['fname']."</td>";
echo "<td>".$row['lname']."</td>";
echo "<td>".$row['email']."</td>";
echo "<td><a href='viewing.php?id=".$row['id']."'>View</a></td>";
echo "<td><a href='updateform.php?id=".$row['id']."'>Update</a></td>";
echo "<td><a href='delete.php?id=".$row['id']."'>Delete</a></td>";
echo "</tr>";
}
echo "</table>";

mysqli_free_result($result);
}
else
{
echo "No records matching your query were found.";

}
 }
mysqli_close($link);

?>
</head>
</body>

</html>

